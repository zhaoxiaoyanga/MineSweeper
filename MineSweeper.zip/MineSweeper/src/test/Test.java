package test;

import menu.Menu;

public class Test {
    public static void main(String[] args) {
        new Menu("扫雷");
    }
}
